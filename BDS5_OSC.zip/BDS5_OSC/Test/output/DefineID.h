//��������Screen0����������ID
#define  _SCREEN_SCREEN0                                                       0

#define  _SELECTOR_SCREEN0_SELECTOR1                                           3

#define  _SELECTOR_SCREEN0_SELECTOR2                                           4

#define  _SLIDER_SCREEN0_SLIDER1                                               9

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY1                                      11

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY2                                      12

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY3                                      23

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY4                                      24

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY5                                      25

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY6                                      26

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY7                                      27

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY8                                      29

#define  _BTN_SCREEN0_BUTTON1                                                 31

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY9                                      32

//����Screen0�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN0_BUTTON2_UP                                               2

//����Screen0�а�ťButton2����ʱ��ͼƬ
#define  _IMG_SCREEN0_BUTTON2_DOWN                                             3

#define  _BTN_SCREEN0_BUTTON2                                                 33

#define  _BTN_SCREEN0_BUTTON3                                                  7

#define  _BTN_SCREEN0_BUTTON4                                                 10

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY10                                     34

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY11                                     35

//����Screen0�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN0_BUTTON5_UP                                               2

//����Screen0�а�ťButton5����ʱ��ͼƬ
#define  _IMG_SCREEN0_BUTTON5_DOWN                                             3

#define  _BTN_SCREEN0_BUTTON5                                                 15

#define  _GRAPH_SCREEN0_GRAPH1                                                 1

