/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "obase.h"
#include "lcd5510.h"
#include "arm_math.h"
#include "math.h"
#include "outputdata.h"
#include "string.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ADCTIMES 	3		//ADC采样次数or序列个数

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */


extern arm_pid_instance_f32 DCPID;

extern uint16_t ADC1_Value[6];/*电池电压电流DCDC电压*4*/
extern uint16_t ADC2_Value[ADCTIMES];
extern uint16_t ADC3_Value[8];/**/

uint16_t ADC3_Value_mem1[8];/**/
uint16_t ADC3_Value_mem2[8];/**/

float32_t   Current_Arg;
float32_t   Voltage_Arg;


extern double VSet;

extern float32_t BT_VReal;
extern float32_t BT_CReal;
extern float32_t DC_VReal;
extern float32_t PW_VReal;
extern float32_t PW_CReal_1;
extern float32_t PW_CReal_2;

extern float32_t DCVSet;

extern float32_t Freq;

extern int16_t PWM;

volatile uint32_t tick;
volatile uint32_t A_tick;
volatile uint32_t Ala_tick;
volatile uint32_t B_tick;
int8_t ADCflag=0;

double DCpid_error;


extern float OutData[4];

extern uint8_t Mode;
extern uint8_t frame;

extern const float COSA[];
extern const float COSB[];
extern const float COSC[];

uint16_t COSNum=0;
float32_t COSNul=1.0;
uint16_t ARR=5600-1;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M4 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Pre-fetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F4xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f4xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles EXTI line1 interrupt.
  */
void EXTI1_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI1_IRQn 0 */

  /* USER CODE END EXTI1_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_1);
  /* USER CODE BEGIN EXTI1_IRQn 1 */

  /*ROW4*/
	if( (HAL_GetTick()-tick)>30)
	{
	for(uint8_t i=7;i<14;i+=2)
	{
		HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_SET);
		PEout(i)=0;
		if(PGin(1)==0)
		{
			switch(i)
			{
				case 13:
				{

					while(PGin(1)==0){}


					goto END;
				}
				case 11:
				{
					while(PGin(1)==0){}


					goto END;
				}
				case 9:
				{
					while(PGin(1)==0){}


					goto END;
				}
				case 7:
				{
					while(PGin(1)==0){}


					goto END;
				}
			}
				END:
				break;
		}
	}
	HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_RESET);
	tick = HAL_GetTick();
	}
  /* USER CODE END EXTI1_IRQn 1 */
}

/**
  * @brief This function handles EXTI line2 interrupt.
  */
void EXTI2_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI2_IRQn 0 */

  /* USER CODE END EXTI2_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_2);
  /* USER CODE BEGIN EXTI2_IRQn 1 */
  Ala_tick=A_tick;
  A_tick=TIM5->CNT;
  ADCflag=1;
  /* USER CODE END EXTI2_IRQn 1 */
}

/**
  * @brief This function handles EXTI line3 interrupt.
  */
void EXTI3_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI3_IRQn 0 */

  /* USER CODE END EXTI3_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_3);
  /* USER CODE BEGIN EXTI3_IRQn 1 */
  B_tick=TIM5->CNT;
  /* USER CODE END EXTI3_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[9:5] interrupts.
  */
void EXTI9_5_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI9_5_IRQn 0 */

  /* USER CODE END EXTI9_5_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_8);
  /* USER CODE BEGIN EXTI9_5_IRQn 1 */
  //ROW3
	if( (HAL_GetTick()-tick)>30)
	{

	for(uint8_t i=7;i<14;i+=2)
	{
		HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_SET);
		PEout(i)=0;
		if(PEin(8)==0)
		{
			switch(i)
			{
				case 13:
				{
					while(PEin(8)==0){}
					Mode=0;
					PWM=0;
					TIM3->CCR1 = PWM;
					goto END;

				}
				case 11:
				{
					while(PEin(8)==0){}
					Mode=1;
					PWM=0;
					TIM3->CCR1 = PWM;
					goto END;
				}
				case 9:
				{
					while(PEin(8)==0){}
					frame=0;
					goto END;
				}
				case 7:
				{
					while(PEin(8)==0){}
					frame=1;
					goto END;
				}
			}
				END:
				break;
		}
	}
	HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_RESET);
	tick = HAL_GetTick();

	}

  /* USER CODE END EXTI9_5_IRQn 1 */
}

/**
  * @brief This function handles TIM2 global interrupt.
  */
void TIM2_IRQHandler(void)
{
  /* USER CODE BEGIN TIM2_IRQn 0 */

  /* USER CODE END TIM2_IRQn 0 */
  HAL_TIM_IRQHandler(&htim2);
  /* USER CODE BEGIN TIM2_IRQn 1 */
  TIM2->CCR1=(COSA[COSNum]*COSNul+1.0)*(TIM2->ARR-1)/2.0;
  TIM2->CCR3=(COSB[COSNum]*COSNul+1.0)*(TIM2->ARR-1)/2.0;
  TIM2->CCR4=(COSC[COSNum]*COSNul+1.0)*(TIM2->ARR-1)/2.0;
  COSNum++;
  if (COSNum==600)
  {
  	COSNum=0;
	}
  if((TIM5->CNT)-A_tick>((A_tick-Ala_tick)/4.0)&&ADCflag==1)
  {
		memcpy(ADC3_Value_mem1,ADC3_Value,16);
		HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
		COSNum=0;
		ADCflag=2;
  }
  if((TIM5->CNT)-A_tick>((A_tick-Ala_tick)*3.0/4.0)&&ADCflag==2)
  {
		memcpy(ADC3_Value_mem2,ADC3_Value,16);
		HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
  	ADCflag=0;
  }
  /* USER CODE END TIM2_IRQn 1 */
}

/**
  * @brief This function handles TIM3 global interrupt.
  */
void TIM3_IRQHandler(void)
{
  /* USER CODE BEGIN TIM3_IRQn 0 */

  /* USER CODE END TIM3_IRQn 0 */
  HAL_TIM_IRQHandler(&htim3);
  /* USER CODE BEGIN TIM3_IRQn 1 */

//  for(int i = 0; i < ADCTIMES;)
//			{
//  			BT_VReal = ADC1_Value[i++]/4095.0*3.3;
//  			BT_CReal = ADC1_Value[i++]/4095.0*3.3;
//			}

  	PW_VReal=0.0;
  	PW_CReal_1=0.0;
  	PW_CReal_2=0.0;
    for(int i = 0; i < 8;i++)
  	{
    	if (i%2==0) {
    		PW_VReal += ADC3_Value_mem1[i]/4095.0*3.3*10.0/4.0;
			}
    	else
    	{
    		PW_CReal_1 += ADC3_Value_mem1[i]/4095.0*3.3/4.0;
    		PW_CReal_2 += ADC3_Value_mem2[i]/4095.0*3.3/4.0;
    	}
  	}

    DC_VReal=0.0;
    for(int i = 2; i < 6;i++)
  	{
    		DC_VReal += ADC1_Value[i]/4095.0*3.3*13.0/4.0;
  	}
    		DCpid_error = PW_VReal - DC_VReal;
    		PWM += arm_pid_f32(&DCPID, DCpid_error);
//	  if(PWM>2520-1)
//	  {
//		  	PWM=2520-1;
//		  	TIM2->CCR2 = (TIM2->ARR-1)*0.9;
//	  }
//	  else if(PWM<0)
//	  {
//	  		PWM=0;
//	  		TIM2->CCR2 = 0;
//	  }
//	  else
//	  {
//	  		TIM2->CCR2 = PWM;
//	  }
    		TIM2->CCR2 = 0;
	  //Freq=1000000.0/(A_tick-Ala_tick);
	  if((A_tick-Ala_tick)<20408&&(A_tick-Ala_tick)>19607)
	  {
//	  	if(TIM2->CNT>((((A_tick-Ala_tick)*84)/600)-1))
//	  	{
//	  		TIM2->CNT=((((A_tick-Ala_tick)*84)/600)-1);
//	  	}
	  	TIM2->ARR=(((A_tick-Ala_tick)*84)/600)-1;
	  }

  /* USER CODE END TIM3_IRQn 1 */
}

/**
  * @brief This function handles EXTI line[15:10] interrupts.
  */
void EXTI15_10_IRQHandler(void)
{
  /* USER CODE BEGIN EXTI15_10_IRQn 0 */

  /* USER CODE END EXTI15_10_IRQn 0 */
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_10);
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_12);
  /* USER CODE BEGIN EXTI15_10_IRQn 1 */
	//ROW1
	if( (HAL_GetTick()-tick)>30)
	{

			if(HAL_GPIO_ReadPin(ROW1_GPIO_Port, ROW1_Pin)==0)
			{
				for(uint8_t i=7;i<14;i+=2)
				{
						HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_SET);
						PEout(i)=0;
						if(PEin(12)==0)
						{
							switch(i)
							{
								case 13:
								{
									while(PEin(12)==0){}
//									if((VSet-0.1)<0.0)
//									{
//										VSet=0.0;
//									}
//									else{
//										CurrentSet-=0.1;
//									}
									goto END;

								}
								case 11:
								{
									while(PEin(12)==0){}
//									if((CurrentSet-0.02)<0.0)
//									{
//										CurrentSet=0.0;
//									}
//									else
//									{
//										CurrentSet-=0.02;
//									}
									goto END;


								}
								case 9:
								{
									while(PEin(12)==0){}
//									if((CurrentSet+0.02)>30.0)
//									{
//										CurrentSet=30.0;
//									}
//									else
//									{
//										CurrentSet+=0.02;
//									}
									goto END;
								}
								case 7:
								{
									while(PEin(12)==0){}
//									if((CurrentSet+0.1)>30.0)
//									{
//										CurrentSet=30.0;
//									}
//									else
//									{
//										CurrentSet+=0.1;
//									}
									goto END;
								}
							}
								END:
								break;
						}
			}
  }

  if(HAL_GPIO_ReadPin(ROW2_GPIO_Port, ROW2_Pin)==0)
  {
			//ROW2
			for(uint8_t i=7;i<14;i+=2)
			{
				HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_SET);
				PEout(i)=0;
				if(PEin(10)==0)
				{
					switch(i)
					{
						case 13:
						{

							while(PEin(10)==0){}
							if((PWM-160)<0)
							{
								PWM=0;
								TIM3->CCR1 = PWM;
							}
							else
							{
								PWM-=160;
								TIM3->CCR1 = PWM;
							}
							goto END2;
						}
						case 11:
						{
							while(PEin(10)==0){}
							if((PWM-32)<0)
							{
								PWM=0;
								TIM3->CCR1 = PWM;
							}
							else
							{
								PWM-=32;
								TIM3->CCR1 = PWM;
							}
							goto END2;


						}
						case 9:
						{
							while(PEin(10)==0){}
							if((PWM+32)>3200)
							{
								PWM=2;
								TIM3->CCR1 = PWM;
							}
							else
							{
								PWM+=32;
								TIM3->CCR1 = PWM;
							}
							goto END2;


						}
						case 7:
						{
							while(PEin(10)==0){}
							if((PWM+160)>3200)
							{
								PWM=3200;
								TIM3->CCR1 = PWM;
							}
							else
							{
								PWM+=160;
								TIM3->CCR1 = PWM;
							}
							goto END2;
						}
					}
						END2:
						break;
				}
  	}
  }
  HAL_GPIO_WritePin(GPIOE,COL1_Pin|COL2_Pin|COL3_Pin|COL4_Pin, GPIO_PIN_RESET);
	tick = HAL_GetTick();
}



  /* USER CODE END EXTI15_10_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
