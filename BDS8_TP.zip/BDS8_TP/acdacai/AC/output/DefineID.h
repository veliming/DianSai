//��������Screen0����������ID
#define  _SCREEN_SCREEN0                                                       0

#define  _PROGRESS_SCREEN0_PROGRESS1                                           3

#define  _SLIDER_SCREEN0_SLIDER1                                               2

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY1                                       4

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY2                                       5

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY3                                       6

#define  _PROGRESS_SCREEN0_PROGRESS2                                           8

#define  _SLIDER_SCREEN0_SLIDER2                                               9

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY6                                      12

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY7                                      13

#define  _TXT_DIS__SCREEN0_TEXT_DISPLAY8                                      14

#define  _BTN_SCREEN0_BUTTON1                                                 23

